
public class StackEception extends Exception {
	public StackEception(String errMsg)
	{
		super(errMsg);
	}

}
