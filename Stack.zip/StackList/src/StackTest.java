
public class StackTest {

	public static void main(String[] args) throws StackEception  {

		Stack st = new Stack(10);
		//Integer num = new Integer(506);
		
		st.pushItem(56);
		st.pushItem(89);
		st.pushItem(45);
		st.pushItem(76453);
		st.pushItem(4523);
		st.pushItem(23);
		st.pushItem(89);
		System.out.println(st.toString());	
		System.out.println(st.topItem());
		st.popItem();
		System.out.println(st.toString());
		
		System.out.println(st.topItem());
		System.out.println(st.isEmpty());	
		st.popItem();
		st.popItem();
		st.popItem();
		st.popItem();
		st.popItem();
		st.popItem();
		System.out.println(st.toString());
		System.out.println(st.isEmpty());
		
			 /*
				try {
					Stack st = new Stack(1000);
					Integer num = new Integer(506);
					
					st.pushItem(num);
					
				} catch (StackEception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
*/
	}

}
