import java.util.Arrays;

public class Stack <T>{
	private Object [] arr;
	private Object temp;
	public Stack(int length) throws StackEception {
		super();
		if (length <=0)
			throw new StackEception("Illegal length");
		
		arr=new Object [length];
	}
	public void pushItem( T item) throws StackEception
	  {
		for(int i=arr.length-1 ; i>0; i--){
			if(arr[0]==null){
				arr[0]=item;
				return;
			}
			else if(arr[i]==null && arr[i-1]!=null){
				arr[i]=arr[i-1];
			}
			else if (arr[i]!=null && arr[i-1]!=null){
				arr[i]=arr[i-1];
			}
		}
		arr[0]=item;
		
	  } 
		
		
	  public T popItem() throws StackEception
	  {
		  if(isEmpty()){
			  throw new StackEception("Stack is empty");
		  }
		  else{
			  temp=arr[0];
			  for(int i=0 ;arr[i]!=null ; i++){
				  arr[i]=arr[i+1];
			  }
		  }
		  return (T)temp;

	  }
	public T topItem() throws StackEception{
		 for(int i=0 ;i<arr.length ; i++){
			 if(isEmpty()){
				 throw new StackEception("Stack is empty");
			 }
			 else if (arr[i]==null && arr[i-1]!=null){
				 temp= arr[i-1];
			 }
		 }
		return (T)temp; 
	}

	public boolean isEmpty(){
		if(arr[0]==null){
			return true;
		}
		return false;	
	}
	@Override
	public String toString() {
		String str="Stack arr\n";
		 for(int i=0 ;arr[i]!=null ; i++){
			  str+="Index " + i +" is: " +arr[i] +"\n";
		  }
		return str;
	} 

}
